//
//  GameBackground.cpp
//  Dungeon Rebuild
//
//  Created by Pavel Bibichenko on 24/04/2019.
//  Copyright © 2019 Pavel Bibichenko. All rights reserved.
//

#include "GameBackground.hpp"


GameBackground::GameBackground(std::string aName, int mScale, int tSize, int xs, int ys, int txs, int yxs) :
assetName(aName), mapScale(mScale), tileSize(tSize), xSize(xs), ySize(ys), xTileSize(txs), yTileSize(yxs) {
    map = new int*[ySize];
    for (int i=0; i<ySize; i++) {
        map[i] = new int[xSize];
        for (int j=0; j<xSize; j++)
            map[i][j] = 0;
    }
    
    texture = GameEngine::assets->getTexture(assetName);
}

void GameBackground::render() {
    //    tile.addComponent<TileComponent>(xSrc, ySrc, xPos, yPos, tileSize, mapScale, textureID);
    int xCount, yCount, element, scale = tileSize*mapScale;
    SDL_Rect srcRect, destRect;
    
    for (int i=0; i<ySize; i++)
        for (int j=0; j<xSize; j++) {
            element = map[i][j];
            yCount = element/xTileSize;
            xCount = element-yCount*xTileSize;
            
            srcRect.x = xCount*tileSize;
            srcRect.y = yCount*tileSize;
            srcRect.w = srcRect.h = tileSize;
            
            destRect.x = j*scale - GameEngine::camera.x;
            destRect.y = i*scale - GameEngine::camera.y;
            destRect.w = destRect.h = scale;
            
            TextureManager::drawTexture(texture, srcRect, destRect, SDL_FLIP_NONE);
        }
}

