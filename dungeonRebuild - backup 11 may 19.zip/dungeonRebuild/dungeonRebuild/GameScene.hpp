//
//  GameScene.hpp
//  DungeonRebuild
//
//  Created by Pavel Bibichenko on 11/05/2019.
//  Copyright © 2019 Pavel Bibichenko. All rights reserved.
//

#ifndef GameScene_hpp
#define GameScene_hpp

#include <SDL2/SDL.h>

#include "GameMap.hpp"

/* SDL_Rect GameEngine::camera = {0, 0, 1024, 867};
 
 Manager manager;
 GameMap *gameMap;
 GameBackground *gameBackground;
 GameWall *gameWall;
 AssetManager *GameEngine::assets = new AssetManager(&manager);
 
 std::vector<ColliderComponent*> GameEngine::colliders;
 
 auto &player(manager.addEntity());
 
 auto& tiles(manager.getGroup(GameEngine::groupMap));
 auto& players(manager.getGroup(GameEngine::groupPlayers));
 auto& enemies(manager.getGroup(GameEngine::groupEnemies));
 auto& projectiles(manager.getGroup(GameEngine::groupProjectiles));*/

class GameScene {
    enum groupLabels : size_t {
        groupPlayers,
        groupTiles,
        groupEnemies,
        groupPeaceful,
        groupColliders,
        groupProjectiles
    };
    
public:
    const char* name;
    
    SDL_Rect camera;
    Manager *manager;
    GameMap *map;
    GameBackground *background;
    GameWall *wall;
    std::vector<ColliderComponent *> colliders;
    
    Entity *currentPlayer;
    std::vector<Entity *> *players;
    std::vector<Entity *> *tiles;
    std::vector<Entity *> *enemies;
    std::vector<Entity *> *peaceful;
    std::vector<Entity *> *projectiles;
    
    AssetManager *assets;
    
    GameScene(const char* nm);
    ~GameScene();
    
    void init() {}
    
    void update();
    void render();
    
    void addAsset();
    void addWalls();
    void addTiles();
    void addBackground();
    void addCreature();
    void addPlayer();
};

#endif /* GameScene_hpp */
