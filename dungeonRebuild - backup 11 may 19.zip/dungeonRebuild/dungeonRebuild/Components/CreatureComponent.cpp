//
//  CreatureComponent.cpp
//  DungeonRebuild
//
//  Created by Pavel Bibichenko on 26/04/2019.
//  Copyright © 2019 Pavel Bibichenko. All rights reserved.
//

#include "CreatureComponent.hpp"

void CreatureComponent::update() {
    if (health > maxHealth)
        health = maxHealth;
    
    if (health <= 0) {
        if (entity->hasComponent<PlayerComponent>())
            entity->getComponent<KeyboardController>().locked = true;
        else
            entity->destroy();
    }
}

void CreatureComponent::render() {
    if (health <= 0)
        if (entity->hasComponent<PlayerComponent>()) {
            srcRect.x = 0;
            srcRect.y = 0;
            srcRect.w = 32;
            srcRect.h = 32;
            
            destRect.x = 0;
            destRect.y = 0;
            destRect.w = 1200;
            destRect.h = 1200;
            
            TextureManager::drawTexture(GameEngine::assets->getTexture("black"), srcRect, destRect, SDL_FLIP_NONE);
            
            TextManager::writeText("GAME OVER.", 420, 400, 50, {255, 255, 255});
        }
}

