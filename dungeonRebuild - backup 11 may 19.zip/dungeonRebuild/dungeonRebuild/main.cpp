//
//  main.cpp
//  dungeonCrawler
//
//  Created by Pavel Bibichenko on 13/02/2019.
//  Copyright © 2019 Pavel Bibichenko. All rights reserved.
//

#include <iostream>
#include <cstring>
#include <SDL2/SDL.h>
#include <SDL2_ttf/SDL_ttf.h>

#include "GameEngine.hpp"

GameEngine *gameEngine = nullptr;

const char *workingDirectory;

int main(int argc, const char * argv[]) {
    workingDirectory = argv[0];
    
    size_t i;
    for (i=strlen(workingDirectory)-1; workingDirectory[i]!='/'; i--);
    for (i--; workingDirectory[i]!='/'; i--);
    ((char*)workingDirectory)[i]=0;
    
    const int FPS = 60;
    const int frameDelay = 1000 / FPS;
    
    Uint32 frameStart;
    int frameTime;
    
    gameEngine = new GameEngine;
    
    gameEngine->init("Dungeon Rebuild", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1024, 896, false);
    
    while (gameEngine->isRunning()) {
        frameStart = SDL_GetTicks();
        
        gameEngine->handleEvents();
        gameEngine->update();
        gameEngine->render();
        
        frameTime = SDL_GetTicks() - frameStart;
        
        if (frameDelay > frameTime) {
            SDL_Delay(frameDelay - frameTime);
        }
    }
    
    gameEngine->clean();

    return 0;
}
