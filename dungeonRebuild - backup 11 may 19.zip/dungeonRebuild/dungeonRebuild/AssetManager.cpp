//
//  AssetManager.cpp
//  dungeonRebuild
//
//  Created by Pavel Bibichenko on 20/04/2019.
//  Copyright © 2019 Pavel Bibichenko. All rights reserved.
//

#include "AssetManager.hpp"

AssetManager::AssetManager(Manager* mgr) : manager(mgr) {}

void AssetManager::addTexture(std::string id, const char* filepath) {
    textures.emplace(id, TextureManager::loadTexture(filepath));
}

SDL_Texture *AssetManager::getTexture(std::string id) {
    return textures[id];
}

void AssetManager::createProjectile(Vector2D position, Vector2D velocity, int range, int speed, std::string textureID, std::string tag) {
    auto& projecttile(manager->addEntity());
    projecttile.addComponent<TransformComponent>(position.x, position.y, 18, 25, 4);
    projecttile.addComponent<SpriteComponent>(textureID, false);
    projecttile.addComponent<ProjectileComponent>(range, speed, velocity, tag);
    projecttile.addComponent<ColliderComponent>("projectile", 30, 10, 18, 25);
    projecttile.addGroup(GameEngine::groupProjectiles);
}
