//
//  GameEngine.hpp
//  dungeonCrawler
//
//  Created by Pavel Bibichenko on 07/03/2019.
//  Copyright © 2019 Pavel Bibichenko. All rights reserved.
//

#ifndef GameEngine_hpp
#define GameEngine_hpp

#include <iostream>
#include <vector>
#include <random>

#include <SDL2/SDL.h>
#include <SDL2_ttf/SDL_ttf.h>
#include <SDL2_image/SDL_image.h>

#include "TextureManager.hpp"
#include "AssetManager.hpp"
#include "GameObject.hpp"
#include "GameMap.hpp"
#include "GameBackground.hpp"
#include "GameWall.hpp"

#include "ECS.hpp"
#include "Components.hpp"

#include "Vector2D.hpp"

#include "Collision.hpp"

class ColliderComponent;
class AssetManager;

class GameEngine {
    SDL_Window *window;
    SDL_DisplayMode displayMode;
    
    bool runningStatus;
    
public:
    static SDL_Renderer *renderer;
    static SDL_Event event;
    static std::vector<ColliderComponent*> colliders;
    static SDL_Rect camera;
    static AssetManager *assets;
    
    void init(const char* name, int xPos, int yPos, int width, int height, bool fullscreen);
    
    void handleEvents();
    void update();
    void render();
    void clean();
    
    bool isRunning() { return runningStatus; }
    
    enum groupLabels : std::size_t {
        groupPlayers,
        groupMap,
        groupEnemies,
        groupColliders,
        groupProjectiles
    };
    
    void initGame();
    void addBackground();
    void addTiles();
    void addCreatures();
    void addWalls();
    void loadAssets();
    
    void spawnEnemy(int x, int y, int s);
};

#endif /* GameEngine_hpp */
