//
//  Projectile.cpp
//  dungeonRebuild
//
//  Created by Pavel Bibichenko on 20/04/2019.
//  Copyright © 2019 Pavel Bibichenko. All rights reserved.
//

#include "ProjectileComponent.hpp"

void ProjectileComponent::init() {
    transform = &entity->getComponent<TransformComponent>();
    transform->velocity = velocity;
    transform->speed = speed;
    
    
}

void ProjectileComponent::update() {
    distance += speed;
    if (distance > range)
        entity->destroy();
    else if (transform->position.x > GameEngine::camera.x + GameEngine::camera.w ||
             transform->position.x < GameEngine::camera.x ||
             transform->position.y > GameEngine::camera.y + GameEngine::camera.h ||
             transform->position.y < GameEngine::camera.y)
        entity->destroy();
}
