//
//  GameBackground.hpp
//  Dungeon Rebuild
//
//  Created by Pavel Bibichenko on 24/04/2019.
//  Copyright © 2019 Pavel Bibichenko. All rights reserved.
//

#ifndef GameBackground_hpp
#define GameBackground_hpp

extern const char* workingDirectory;

#include <iostream>
#include <fstream>
#include <cstring>

#include "GameEngine.hpp"

class GameBackground {
public:
    int **map;
    
    std::string assetName;
    SDL_Texture *texture;
    
    int mapScale;
    int xSize, ySize;
    
    int tileSize;
    int xTileSize, yTileSize;
    
    GameBackground(std::string aName, int mScale, int tSize, int xs, int ys, int txs, int yxs);
    
    ~GameBackground() {
        for (int i=0; i<ySize; i++) {
            for (int j=0; j<xSize; j++)
                delete &map[i][j];
            delete[] map[i];
        }
    }
    
    void loadFile(const char* filepath) {
        std::fstream mapFile;
        
        char *fullPath = new char[255];
        strcpy(fullPath, workingDirectory);
        strcat(fullPath, filepath);
        
        mapFile.open(fullPath);
        
        std::cout << "[Map - LoadMap] Loading layer from " << fullPath << mapFile.is_open() << "\n";
        
        if (mapFile.is_open() == 0)
            return;
        
        int newTile;
        
        for (int i=0; i<ySize; i++)
            for (int j=0; j<xSize; j++) {
                mapFile >> newTile;
                
                if (newTile != -1)
                    map[i][j] = newTile;
            }
        
        mapFile.close();
    }
    
    void render();
};

#endif /* GameBackground_hpp */
