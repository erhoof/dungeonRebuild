//
//  GameScene.cpp
//  DungeonRebuild
//
//  Created by Pavel Bibichenko on 11/05/2019.
//  Copyright © 2019 Pavel Bibichenko. All rights reserved.
//

#include "GameScene.hpp"

GameScene::GameScene(const char* nm) : name(nm) {
    manager = new Manager();
    
    currentPlayer = &manager->addEntity();
    currentPlayer->addGroup(groupPlayers);
    
    players = &manager->getGroup(groupPlayers);
    tiles = &manager->getGroup(groupTiles);
    enemies = &manager->getGroup(groupEnemies);
    peaceful = &manager->getGroup(groupPeaceful);
    projectiles = &manager->getGroup(groupProjectiles);
    
    assets = new AssetManager(manager);
}

GameScene::~GameScene() {
    delete manager;
    delete map;
    delete background;
    delete wall;
    
    delete currentPlayer;
    
    delete assets;
}
