//
//  GameEngine.cpp
//  dungeonCrawler
//
//  Created by Pavel Bibichenko on 07/03/2019.
//  Copyright © 2019 Pavel Bibichenko. All rights reserved.
//

#include "GameEngine.hpp"

SDL_Renderer *GameEngine::renderer = nullptr;
SDL_Event GameEngine::event;

SDL_Rect GameEngine::camera = {0, 0, 1024, 867};

Manager manager;
GameMap *gameMap;
GameBackground *gameBackground;
GameWall *gameWall;
AssetManager *GameEngine::assets = new AssetManager(&manager);

std::vector<ColliderComponent*> GameEngine::colliders;

auto &player(manager.addEntity());

auto& tiles(manager.getGroup(GameEngine::groupMap));
auto& players(manager.getGroup(GameEngine::groupPlayers));
auto& enemies(manager.getGroup(GameEngine::groupEnemies));
auto& projectiles(manager.getGroup(GameEngine::groupProjectiles));

void GameEngine::init(const char* name, int xPos, int yPos, int width, int height, bool fullscreen) {
    Uint32 sdlFlags = 0;
    
    displayMode.w = width;
    displayMode.h = height;
    
    if (fullscreen)
        sdlFlags = SDL_WINDOW_FULLSCREEN;
    
    std::cout << "[GameEngine] Found " << name << std::endl;
    if (SDL_Init(SDL_INIT_EVERYTHING) == 0) {
        std::cout << "[GameEngine] Session started\n";
        window = SDL_CreateWindow(name, xPos, yPos, displayMode.w, displayMode.h, sdlFlags);
        if (window)
            std::cout << "[GameEngine - Window] Window created\n";
        else
            std::cout << "[GameEngine - Window] Window initialization failure\n";
        renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED | SDL_RENDERER_PRESENTVSYNC);
        if (renderer)
            std::cout << "[GameEngine - Renderer] Renderer created\n";
        else
            std::cout << "[GameEngine - Renderer] Renderer initialization failure\n";
        
        runningStatus = true;
        
        TTF_Init();
    } else {
        std::cout << "[GameEngine] Initialization error. Closing...\n";
        runningStatus = false;
        
        return;
    }
    
    camera.w = 8*4*80/2+1024/4;
    camera.h = 8*4*80/2+896/4 + 32*4+8*4;
    //camera.h += (896/4) + 16*2;
    
    initGame();
    
    std::cout << "SIZE: " << colliders.size() << std::endl;
}

void GameEngine::handleEvents() {
    SDL_PollEvent(&event);
    
    switch(event.type) {
        case SDL_QUIT:
            runningStatus = false;
            break;
    }
}

void GameEngine::update() {
    Vector2D playerPosition = player.getComponent<TransformComponent>().position;
    
    TransformComponent *transform = &player.getComponent<TransformComponent>();
    
    manager.refresh();
    manager.update();
    
    if (gameWall->checkDestination(player.getComponent<ColliderComponent>().collider)) {
        
        transform->position.x -= transform->velocity.x * transform->speed;
        transform->position.y -= transform->velocity.y * transform->speed;
        
        transform->velocity.zero();
    }
    
    for (auto& e: enemies) {
        transform = &e->getComponent<TransformComponent>();
        
        if (gameWall->checkDestination(e->getComponent<ColliderComponent>().collider)) {
            
            transform->position.x -= transform->velocity.x * transform->speed;
            transform->position.y -= transform->velocity.y * transform->speed;
            
            transform->velocity.zero();
        }
    }
    
    for (auto& p: projectiles) {
        if (Collision::AABB(player.getComponent<ColliderComponent>().collider, p->getComponent<ColliderComponent>().collider)) {
            if (p->getComponent<ProjectileComponent>().tag == "slash") {
                player.getComponent<CreatureComponent>().health -= 1;
                p->destroy();
            }
        }
        
        for (auto& e: enemies) {
            if (Collision::AABB(e->getComponent<ColliderComponent>().collider, p->getComponent<ColliderComponent>().collider)) {
                if (p->getComponent<ProjectileComponent>().tag == "pSlash") {
                    e->getComponent<CreatureComponent>().health -= 1;
                    p->destroy();
                }
            }
        }
    }
    
    camera.x = playerPosition.x - (1024/2) + 16*4;
    camera.y = playerPosition.y - (896/2) + 16*4;
    
    if (camera.x < 0)
        camera.x = 0;
    
    if (camera.y < 0)
        camera.y = 0;

    if (camera.x > camera.w)
        camera.x = camera.w;
    
    if (camera.y > camera.h)
        camera.y = camera.h;
}

void GameEngine::render() {
    SDL_RenderClear(renderer);
    
    gameBackground->render();
    
    for (auto& t : tiles)
        t->render();
    
    for (auto& t : enemies)
        t->render();
    
    for (auto& t : players)
        t->render();
    
    for (auto& p: projectiles)
        p->render();
    
    SDL_RenderPresent(renderer);
}

void GameEngine::clean() {
    SDL_DestroyWindow(window);
    SDL_DestroyRenderer(renderer);
    SDL_Quit();
    
    std::cout << "[GameEngine] Session closed.\n";
}


// Game
void GameEngine::loadAssets() {
    assets->addTexture("tileset", "/Resources/Assets/Sets/tileset.png");
    assets->addTexture("hud", "/Resources/Assets/Sets/hud.png");
    
    assets->addTexture("player", "/Resources/Assets/Characters/linkSprites.png");
    assets->addTexture("enemy", "/Resources/Assets/Characters/alinkSprites.png");
    
    assets->addTexture("collider", "/Resources/Assets/Characters/collider.png");
    assets->addTexture("black", "/Resources/Assets/Sets/black.png");
    assets->addTexture("arrow", "/Resources/Assets/Sets/arrow.png");
}

void GameEngine::addBackground() {
    gameBackground = new GameBackground("tileset", 4, 8, 80, 80, 40, 40);
    
    gameBackground->loadFile("/Resources/Assets/Maps/map1_b.map");
    gameBackground->loadFile("/Resources/Assets/Maps/map1_r.map");
    gameBackground->loadFile("/Resources/Assets/Maps/map1_c.map");
    
    //gameBackground->loadFile("/Resources/Assets/Maps/map1_e.map");
    gameBackground->loadFile("/Resources/Assets/Maps/map1_g.map");
}

void GameEngine::addTiles() {
    //gameMap = new GameMap("tileset", 4, 8, 80, 80, 40, 40);
    
    //gameMap->loadFile("/Resources/Assets/Maps/map1_w.map");
}

void GameEngine::addCreatures() {
    spawnEnemy(500, 500, 2);
    spawnEnemy(600, 500, 3);
    spawnEnemy(700, 500, 1);
    spawnEnemy(800, 500, 4);
}

void GameEngine::addWalls() {
    gameWall = new GameWall(4, 8, 80, 80);
    
    gameWall->loadFile("/Resources/Assets/Maps/map1_w.map");
}

void GameEngine::initGame() {
    loadAssets();
    
    addBackground();
    addTiles();
    addCreatures();
    
    player.addComponent<TransformComponent>(200, 525, 32, 32, 4);
    player.addComponent<ColliderComponent>("player", 30, 20, 18, 20);
    player.addComponent<SpriteComponent>("player", true);
    player.addComponent<KeyboardController>();
    player.addComponent<CreatureComponent>(40);
    player.addComponent<PlayerComponent>();
    player.addComponent<HUDController>("hud");
    player.addGroup(groupPlayers);
    
    addWalls();
}

void GameEngine::spawnEnemy (int x, int y, int s) {
    auto& enemy(manager.addEntity());
    
    enemy.addComponent<TransformComponent>(x, y, 4, s);
    enemy.addComponent<SpriteComponent>("enemy", true);
    enemy.addComponent<ColliderComponent>("enemy", 30, 10, 18, 25);
    enemy.addComponent<CreatureComponent>(4);
    enemy.addComponent<EnemyAIComponent>(400);
    
    enemy.addGroup(GameEngine::groupEnemies);
}
